/*---------------------------------------------
Template name:  tf-quickstart || html template
Version:        1.0
Author:         rajibmehedihasan
Author url:     https://github.com/rajibmehedihasan

NOTE:
------
Please DO NOT EDIT THIS JS, you may need to use "custom.js" file for writing your custom js.
We may release future updates so it will overwrite this file. it's better and safer to use "custom.js".

[Table of Content]
----------------------------------------------*/

(function ($) {})(jQuery);
